package client;
 
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
 
public class Sender {
	ObjectOutputStream oos;
	public Sender(){
		Thread senderThread = new Thread(new Runnable() {
			public void run(){
				try{
					Socket socket = new Socket("203.236.209.196", 3000);
					System.out.println("Ŭ���̾�Ʈ ����");
					oos = new ObjectOutputStream(socket.getOutputStream());
					System.out.println("������ ������");
					}catch(IOException e){
				}
			}
		});
 
		senderThread.start();
	}//sender method
 
	public ObjectOutputStream getOutputStream() {
		return oos;
	}
 
}//Sender