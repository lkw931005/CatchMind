package client;
 
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

import sun.font.FontAccess;
 
public class Drawer extends Frame implements MouseMotionListener, WindowListener
{
	int x = 0;
	int y = 0;
 
	Image img = null;
	Graphics gImg = null;
 
	private OutputStream os = null;
 
	public Drawer(OutputStream os){
		
		addMouseMotionListener(this);		
 
		setTitle("Client");
		pack();
		setBounds(100,100,500,500);
		setVisible(true);
 
		img = createImage(500,500);
		gImg = img.getGraphics();
		gImg.drawString("�׸���",10,50);
	}//MakeFrame
 
 
 



	public void mouseDragged(MouseEvent me){
		if(me.getModifiersEx() == MouseEvent.BUTTON1_DOWN_MASK){
			x = me.getX();
			y = me.getY();
			super.paint(gImg);
			gImg.setFont(new Font("����",Font.BOLD,30));
			gImg.drawString("����", x, y);
			String tmp = x+","+y;
			System.out.println(tmp);
			
			
//			try {
//				os.write(tmp.getBytes());
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			
			
//			try {
//				os.write(tmp.getBytes());
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			repaint();//class.x
		}
	}//mouseDragged
 
 
	public void paint(Graphics g){
		if(img!=null)
			g.drawImage(img, 0,0,this);
	} //Paint
 
	public void mouseMoved(MouseEvent e) {
	}
	public void windowActivated(WindowEvent e) {
	}
	public void windowClosed(WindowEvent e) {
	}
	public void windowClosing(WindowEvent e) {
		System.exit(0);
	}
	public void windowDeactivated(WindowEvent e) {
	}
	public void windowDeiconified(WindowEvent e) {
	}
	public void windowIconified(WindowEvent e) {
	}
	public void windowOpened(WindowEvent e) {
	}
}//class