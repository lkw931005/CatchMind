package client;
 
public class Client {
	public static void main(String[] args) {
		Sender sender = new Sender(); 
		Drawer drawer = new Drawer(sender.getOutputStream());
	}
}