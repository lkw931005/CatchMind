package client;

public class Point {

}
