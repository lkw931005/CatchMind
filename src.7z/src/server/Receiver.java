package server;
 
 
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseMotionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
 
public class Receiver extends Frame implements WindowListener{
 
	Socket socket;
	ObjectInputStream ois;
 
	Image img = null;
	Graphics gImg = null;
 
	int x=0;
	int y=0;
 
	public void paint(Graphics g){
		if(img!=null)
			g.drawImage(img, 0,0,this);
	} //Paint
 
	public Receiver(){
		Thread acceptThread = new Thread(new Runnable() {
			public void run() {
				try {
					ServerSocket serverSocket = new ServerSocket(3000);
					System.out.println("서버소켓생성 완료"); 
					while ( !Thread.currentThread().isInterrupted() ) {
 
						System.out.println("접속준비중");
 
						socket = serverSocket.accept();
						System.out.println("접속완료");
						ois = new ObjectInputStream(socket.getInputStream());
 
						setTitle("Server");
						pack();
						setBounds(100,100,500,500); 
						setVisible(true);
 
						img = createImage(500,500);
						gImg.drawString("그림 출력",10,50);
						gImg = img.getGraphics();
 
 
						try{
							System.out.println("받은 데이터 : "+ois.readObject());
							String cdn = (String)ois.readObject();
							String[] a = cdn.split(",");
							for(int i=0;i<2;i++)
							{
								String[] v = a[i].split(":");
								if(v[0].equals("x")){
									x = Integer.parseInt(v[1]);
								}else if(v[0].equals("y")){
									y = Integer.parseInt(v[1]);	
								}//if
 
								gImg.fillOval(x-5/2, y-5/2, 5, 5);
								repaint();
							}//for	
							
						}catch(IOException | ClassNotFoundException e){}//try
						paint(gImg);
					System.out.println(x+" "+y);
					}//while end
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		acceptThread.start();		
	}//Receiver Method
 
	@Override
	public void windowActivated(WindowEvent arg0) {
	}
	@Override
	public void windowClosed(WindowEvent arg0) {
	}
	@Override
	public void windowClosing(WindowEvent arg0) {
		System.exit(0);
	}
	@Override
	public void windowDeactivated(WindowEvent arg0) {
	}
	@Override
	public void windowDeiconified(WindowEvent arg0) {
	}
	@Override
	public void windowIconified(WindowEvent arg0) {
	}
	@Override
	public void windowOpened(WindowEvent arg0) {
	}	
	
	

}//Receiver Class