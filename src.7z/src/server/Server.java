package server;

 
public class Server {
	public static void main(String args[])
	{
		Receiver r = new Receiver();
	}//mains
}