package chat.client;


import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import com.sun.prism.paint.Color;




//��� �޴°Ÿ�!
public class ClientThread extends Thread {

	   CanvasDemo cd1;
	   Socket s1;
	   static int x;
	   static int y;
	   ObjectInputStream ois;
	   String str2;
	   String name;
	   Client client;
	   Object obj;

	   public ClientThread(Socket s1,Client client){   
		   this.s1=s1;
	       this.client=client;

	   } //clientThread end..
	   
	   public void run(){                                
	      try{                
	    	  
	          //srever���� �Ѿ�� �� �ޱ�
	          
	    	 ois=new ObjectInputStream(s1.getInputStream()); 
	    	  
	         while(true){
	        	
	        	String str2="";
	        	obj=ois.readObject();
	        	if(obj instanceof String){
	        	str2=(String)obj;
	            if(str2.indexOf("!@#") == 0){
	            	name=str2.substring(3);
	            	client.addName(name); 

	            }
	            else if(str2.indexOf("<����>")==0)
	            {
	            	client.addName(str2);
	            }

	            else if(str2.indexOf("@~")==0){
	            	
	            	String tmp=str2.substring(2);
	            	String[] lo=tmp.split(",");
	            	x=Integer.parseInt(lo[0]);
	            	y=Integer.parseInt(lo[1]);
	            	cd1=client.getCd();
	            	client.canvasSetting(cd1, x, y);
	            	
//	            	client.chatA.append(x+","+y+"\n"); //�׽�Ʈ
	            }


	            
	            
	            else if(str2.indexOf("����")==0){
	            	String str3=str2.substring(2, str2.length());
	            	client.chatA.append(str3+"\n");
	            	client.deleteName(name);
	            }

	            else {
	               client.chatA.append(str2+"\n");//mainâ���� ���..
	               
//	               System.out.println(x+" "+y);
	               
	            }
	            }//if end

	        	
	        	
	        	
	        	}//while
	        	
	         } //try
	      catch(IOException e){                           //catch ����
	         System.out.println("Error...");
	      } //catch
	      catch (ClassNotFoundException e) {
	      }
	    
	   } //run

	public void settingCanvas(CanvasDemo cd,int x2, int y2) {
		
		cd.x=x2;
		cd.y=y2;

		
		cd.repaint();
		
    	cd.x=x;
    	cd.y=y;
    	cd.getGraphics().fillOval(x, y, 10, 10); // �� ���;
    	cd.repaint();
		
	}



}
