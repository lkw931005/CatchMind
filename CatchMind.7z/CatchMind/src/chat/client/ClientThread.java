package chat.client;


import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.util.ArrayList;

import chat.server.Server;


public class ClientThread extends Thread {

		ArrayList<String> userList=new ArrayList<String>();
		String head;
		Server server;
		CanvasDemo cd1;
		Socket s1;
		static int x;
		static int y;
		ObjectInputStream ois;
		String str2;
		String name;
		Client client;
		Object obj;
		int c;

	   public ClientThread(Socket s1,Client client){   
		   this.s1=s1;
	       this.client=client;

	   } //clientThread end..
	   
	   public void run(){                                
	      try{                
	    	 
	          //srever���� �Ѿ�� �� �ޱ�
	          
	    	 ois=new ObjectInputStream(s1.getInputStream()); 
	    	
	         while(true){
	        	
	        	
	        	String str2="";
	        	obj=ois.readObject();
	        	
	        
	        	if(obj instanceof String){
	        	str2=(String)obj;
	            if(str2.indexOf("!@#") == 0){
	            	name=str2.substring(3);
	            	client.addName(name); 
	            	userList.add(name);
	            	c++;
	            }
	            else if(str2.indexOf("<����>")==0)//�������
	            {
	            	
	            	name=str2.substring(4);
	            	client.addName("<����>"+name);
	            	client.settingRight();
	            	userList.add(name);
	            	head=userList.get(0);
	            	c++;
	            }
	            
	            else if(str2.indexOf("@aty")==0)
	            {
	            	String tmp=str2.substring(4);
	            	int count=Integer.parseInt(tmp);
	            	client.cnt=count;
	            	
	            	System.out.println(c);
	            	
	            }
	            
	            else if(str2.indexOf("/����")==0)
	            {
	            	String tmp=str2.substring(3);//����
	            	client.answer(tmp);
	            	
	            }
	            else if(str2.indexOf("@~")==0){//��ǥ
	            	
	            	String tmp=str2.substring(2);
	            	String[] lo=tmp.split(",");
	            	x=Integer.parseInt(lo[0]);
	            	y=Integer.parseInt(lo[1]);
	            	cd1=client.getCd();
	            	client.canvasSetting(cd1, x, y);
	            	
	            }


	            
	            
	            else if(str2.indexOf("����")==0){
	            	String str3=str2.substring(2, str2.length());
	            	client.chatA.append(str3+"\n");
	            	client.deleteName(name);
	            	System.out.println("���� Ŭ���̾�Ʈ:"+c);
	           
	            }

	            else {
	               client.chatA.append(str2+"\n");//mainâ���� ���..
	               
	            }
	            }//if end
	 
	        	}//while
	        	
	         } //try
	      catch(IOException e){                           //catch ����
	         System.out.println("Error...");
	      } //catch
	      catch (ClassNotFoundException e) {
	      }
	    
	   } //run

	public void settingCanvas(CanvasDemo cd,int x2, int y2) {
		
		cd.x=x2;
		cd.y=y2;

		
		cd.repaint();
		
    	cd.x=x;
    	cd.y=y;
    	cd.getGraphics().fillOval(x, y, 10, 10); // �� ���;
    	cd.repaint();
		
	}



}
