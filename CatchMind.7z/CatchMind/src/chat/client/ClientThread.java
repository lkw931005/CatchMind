package chat.client;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class ClientThread extends Thread {

	
	   Socket s1;
	   BufferedReader br;
	   String str2;
	   String name;
	   Client client;
	   
	   public ClientThread(Socket s1,Client client){   
	      this.s1=s1;
	       this.client=client;
	   } //clientThread end..
	   
	   public void run(){                                
	      try{                                           
	         br=new BufferedReader(new InputStreamReader(s1.getInputStream()));
	          //srever���� �Ѿ�� �� �ޱ�
	          
	         while(true){
	            str2=br.readLine();
	            
	            if(str2.indexOf("!@#") == 0){
	               name = str2.substring(3);
	               client.addName(name); //userList.add(str2);
	            }else {
	               client.chatA.append(str2+"\n");//mainâ���� ���..
	            }
	         } //while
	      } //try
	      catch(IOException e){                           //catch ����
	         System.out.println("Error...");
	        } //catch
	   } //run

}
