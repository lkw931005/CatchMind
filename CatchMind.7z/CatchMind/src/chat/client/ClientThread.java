package chat.client;


import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;


//��� �޴°Ÿ�!
public class ClientThread extends Thread {

	
	   Socket s1;
//	   BufferedReader br;
	   
	   ObjectInputStream ois;
	   String str2;
	   String name;
	   Client client;
	   
	   public ClientThread(Socket s1,Client client){   
	      this.s1=s1;
	       this.client=client;
	   } //clientThread end..
	   
	   public void run(){                                
	      try{                
	    	  
//	         br=new BufferedReader(new InputStreamReader(s1.getInputStream()));
	          //srever���� �Ѿ�� �� �ޱ�
	          
	    	 ois=new ObjectInputStream(s1.getInputStream()); 
	    	  
	         while(true){
	        	
	        	String str2="";
	        	
//	        	if(ois.readObject().equals(str2)){//ois��ü�� StringŸ���̸�...

	        	str2=(String) ois.readObject();
	            if(str2.indexOf("!@#") == 0){
	               name = str2.substring(3);
	               client.addName(name); //userList.add(str2);
	            }else {
	               client.chatA.append(str2+"\n");//mainâ���� ���..
	            }
//	            }//if end
	        	}//while
	        	
	         } //try
	      catch(IOException e){                           //catch ����
	         System.out.println("Error...");
	      } //catch
	      catch (ClassNotFoundException e) {
	    	  // TODO Auto-generated catch block
	    	  e.printStackTrace();
	      }
	    
	   } //run

}
