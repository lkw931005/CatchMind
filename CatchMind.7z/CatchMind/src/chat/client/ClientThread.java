package chat.client;


import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;




//��� �޴°Ÿ�!
public class ClientThread extends Thread {

	
	   Socket s1;
	   
	   ObjectInputStream ois;
	   String str2;
	   String name;
	   Client client;
	   Object obj;
	   
	   public ClientThread(Socket s1,Client client){   
	      this.s1=s1;
	       this.client=client;
	   } //clientThread end..
	   
	   public void run(){                                
	      try{                
	    	  
//	         br=new BufferedReader(new InputStreamReader(s1.getInputStream()));
	          //srever���� �Ѿ�� �� �ޱ�
	          
	    	 ois=new ObjectInputStream(s1.getInputStream()); 
	    	  
	         while(true){
	        	
	        	String str2="";
	        	obj=ois.readObject();
	        	if(obj instanceof String){
	        	str2=(String)obj;
	            if(str2.indexOf("!@#") == 0){
	               name = str2.substring(3);
	               client.addName(name); //userList.add(str2);
	            }

	            else if(str2.indexOf("����")==0){
	            	String str3=str2.substring(2, str2.length());
	            	client.chatA.append(str3+"\n");
	            	client.deleteName(name);
	            }

	            else {
	               client.chatA.append(str2+"\n");//mainâ���� ���..
	            }
	            }//if end
	        	
	        	else{
	        		
	        		////Client�� �߰��ϸ��
	        		CanvasDemo cd=(CanvasDemo)obj; //�޴°ű��� ok
//	        		client.setCanvas(cd);
	        		System.out.println(cd);
	        		
	        		
	        		
	        	}
	        	
	        	
	        	}//while
	        	
	         } //try
	      catch(IOException e){                           //catch ����
	         System.out.println("Error...");
	      } //catch
	      catch (ClassNotFoundException e) {
	      }
	    
	   } //run

}
