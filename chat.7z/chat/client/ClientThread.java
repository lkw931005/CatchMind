package chat.client;


import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;




//��� �޴°Ÿ�!
public class ClientThread extends Thread {

	
	   Socket s1;
	   int x,y;
	   ObjectInputStream ois;
	   String str2;
	   String name;
	   Client client;
	   Object obj;
	   public ClientThread(Socket s1,Client client){   
		   this.s1=s1;
	       this.client=client;

	   } //clientThread end..
	   
	   public void run(){                                
	      try{                
	    	  
//	         br=new BufferedReader(new InputStreamReader(s1.getInputStream()));
	          //srever���� �Ѿ�� �� �ޱ�
	          
	    	 ois=new ObjectInputStream(s1.getInputStream()); 
	    	  
	         while(true){
	        	
	        	String str2="";
	        	obj=ois.readObject();
	        	if(obj instanceof String){
	        	str2=(String)obj;
	            if(str2.indexOf("!@#") == 0){
	               name = str2.substring(3);
	               client.addName(name); //userList.add(str2);
	            }
	            else if(str2.indexOf("@~")==0){
	            	
	            	String tmp=str2.substring(2);
	            	String[] lo=tmp.split(",");
	            	x=Integer.parseInt(lo[0]);
	            	y=Integer.parseInt(lo[1]);
	            	client.canvasSetting(x, y);
//	            	client.canvasSetting(Integer.parseInt(lo[0]),Integer.parseInt(lo[1]));
	            	
	            	client.chatA.append(x+","+y+"\n");
	            }

	            else if(str2.indexOf("����")==0){
	            	String str3=str2.substring(2, str2.length());
	            	client.chatA.append(str3+"\n");
	            	client.deleteName(name);
	            }

	            else {
	               client.chatA.append(str2+"\n");//mainâ���� ���..
	            }
	            }//if end
	        	
	        	
	        	
	        	}//while
	        	
	         } //try
	      catch(IOException e){                           //catch ����
	         System.out.println("Error...");
	      } //catch
	      catch (ClassNotFoundException e) {
	      }
	    
	   } //run

	public void settingCanvas(int x2, int y2) {
		
		client.cd.x=x2;
		client.cd.y=y2;
		client.cd.repaint();
		
	}



}
